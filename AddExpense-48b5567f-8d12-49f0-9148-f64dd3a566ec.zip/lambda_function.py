import json
import boto3
from decimal import Decimal
import uuid

# פונקציה לעיבוד Decimal
class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)  # המרה ל-float
        return super(DecimalEncoder, self).default(obj)

def lambda_handler(event, context):
    try:
        # ניתוח גוף הבקשה
        if isinstance(event['body'], str):
            body = json.loads(event['body'], parse_float=Decimal)  # שימוש ב-Decimal
        else:
            body = event['body']
        
        user_id = body['userId']
        month = body['month']
        expense = body['expense']
        expense['Amount'] = Decimal(str(expense['Amount']))
    except KeyError as e:
        return {
            'statusCode': 400,
            'body': json.dumps(f'Missing key: {str(e)}')
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error parsing body: {str(e)}')
        }

    expense_id = str(uuid.uuid4())
    expense['id'] = expense_id

    dynamo_client = boto3.resource('dynamodb')
    table = dynamo_client.Table('User_Data')

    try:
        response = table.get_item(Key={'User_ID': user_id})
        if 'Item' not in response:
            return {
                'statusCode': 404,
                'body': json.dumps(f'User {user_id} not found')
            }

        current_budget_info = response['Item'].get('BudgetInfo', {}).get(month, None)
        if not current_budget_info:
            return {
                'statusCode': 400,
                'body': json.dumps(f'No budget found for month {month}. Please set a budget first.')
            }

        # שימוש ב-Decimal להבטחת תאימות
        expense_amount = Decimal(str(expense['Amount']))
        current_total_expenses = Decimal(str(current_budget_info.get('TotalExpenses', 0)))
        current_budget_left = Decimal(str(current_budget_info.get('BudgetLeft', 0)))

        if expense_amount > current_budget_left:
            return {
                'statusCode': 400,
                'body': json.dumps('Expense exceeds remaining budget. Cannot add expense.')
            }

        # חישוב ערכים מעודכנים
        updated_total_expenses = current_total_expenses + expense_amount
        updated_budget_left = max(current_budget_left - expense_amount, Decimal(0))

        # עדכון DynamoDB
        response = table.update_item(
            Key={'User_ID': user_id},
            UpdateExpression="""
                SET BudgetInfo.#month.TotalExpenses = :updated_total_expenses,
                    BudgetInfo.#month.BudgetLeft = :updated_budget_left,
                    BudgetInfo.#month.Expenses = list_append(if_not_exists(BudgetInfo.#month.Expenses, :empty_list), :expense)
            """,
            ExpressionAttributeNames={'#month': month},
            ExpressionAttributeValues={
                ':updated_total_expenses': updated_total_expenses,
                ':updated_budget_left': updated_budget_left,
                ':expense': [expense],
                ':empty_list': []
            },
            ReturnValues="UPDATED_NEW"
        )

        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Expense added successfully',
                'updatedAttributes': response['Attributes']
            }, cls=DecimalEncoder)
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error adding expense: {str(e)}')
        }
