import json
import boto3
from datetime import datetime

# Initialize DynamoDB client
dynamodb = boto3.resource('dynamodb')
table_name = "User_Data"  # Replace with your DynamoDB table name
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    try:
        # Log the received event
        print("Received Event:", json.dumps(event))

        # Parse the request body
        body = json.loads(event['body'])

        # Extract necessary fields
        user_id = body.get('userId')
        name = body.get('name')
        email = body.get('email')  # Extract email from the request body
        photo = body.get('photo')
        last_login = datetime.utcnow().isoformat()

        if not user_id:
            return {
                'statusCode': 400,
                'body': json.dumps('userId is required')
            }

        # Check if the user already exists in DynamoDB
        response = table.get_item(Key={'User_ID': user_id})
        if 'Item' not in response:
            # If user doesn't exist, create a new entry with BudgetInfo
            table.put_item(
                Item={
                    'User_ID': user_id,
                    'Name': name if name else 'Unknown User',
                    'Email': email if email else '',
                    'Photo': photo if photo else 'default-photo-url',
                    'LastLogin': last_login,
                    'BudgetInfo': {
                        'Month': {
                            'TotalBudget': 0,
                            'TotalExpenses': 0,
                            'BudgetLeft': 0,
                            'Expenses': []
                        }
                    }
                }
            )
            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': 'true'
                },
                'body': json.dumps('User created successfully')
            }
        else:
            # If user exists, update the necessary fields
            update_expression = ["LastLogin = :last_login"]
            expression_attribute_values = {':last_login': last_login}
            expression_attribute_names = {}

            if name:
                update_expression.append("#name = :name")
                expression_attribute_values[':name'] = name
                expression_attribute_names['#name'] = 'Name'
            if email:
                update_expression.append("Email = :email")
                expression_attribute_values[':email'] = email
            if photo:
                update_expression.append("Photo = :photo")
                expression_attribute_values[':photo'] = photo

            # Perform the update
            table.update_item(
                Key={'User_ID': user_id},
                UpdateExpression="SET " + ", ".join(update_expression),
                ExpressionAttributeValues=expression_attribute_values,
                ExpressionAttributeNames=expression_attribute_names,
                ReturnValues="UPDATED_NEW"
            )

            return {
                'statusCode': 200,
                'headers': {
                    'Access-Control-Allow-Origin': '*',
                    'Access-Control-Allow-Credentials': 'true'
                },
                'body': json.dumps('User updated successfully')
            }
    except Exception as e:
        print(f"Error handling user profile: {str(e)}")
        return {
            'statusCode': 500,
            'headers': {
                'Access-Control-Allow-Origin': '*',
                'Access-Control-Allow-Credentials': 'true',
            },
            'body': json.dumps({'error': f'Failed to update user: {str(e)}'})
        }
