import boto3
import json
import os

s3 = boto3.client('s3')
bucket_name = os.environ['S3_BUCKET']  # Ensure this environment variable is set correctly

def lambda_handler(event, context):
    try:
        # Parse the request body
        body = json.loads(event['body'])
        filename = body.get('filename')

        if not filename:
            return {
                'statusCode': 400,
                'body': json.dumps({'error': 'Filename is required'})
            }

        # Generate the pre-signed URL
        presigned_url = s3.generate_presigned_url(
            'put_object',
            Params={'Bucket': bucket_name, 'Key': filename},
            ExpiresIn=3600
        )

        print(f"Generated pre-signed URL: {presigned_url}")  # Debug log

        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Credentials": "true"
            },
            "body": json.dumps({"upload_url": presigned_url})
        }
    except Exception as e:
        print(f"Error generating pre-signed URL: {str(e)}")  # Debug log
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
