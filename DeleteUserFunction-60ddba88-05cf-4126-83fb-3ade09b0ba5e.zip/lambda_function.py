import json
import boto3

# Initialize DynamoDB and Cognito
dynamodb = boto3.resource('dynamodb')
cognito_idp = boto3.client('cognito-idp')
USER_POOL_ID = "us-east-1_jVVBL0a8C"
table_name = "User_Data"  # Replace with your DynamoDB table name
table = dynamodb.Table(table_name)

def lambda_handler(event, context):
    print("Raw event received:", event)  # Log the raw event for debugging
    try:
        # Parse the 'body' field (it will be a string in proxy integration)
        body_str = event.get('body', '{}')  # Default to an empty JSON string
        body = json.loads(body_str)  # Convert the body string to a dictionary

        # Extract the userId from the body
        user_id = body.get('userId')
        if not user_id:
            return {
                "statusCode": 400,
                "body": json.dumps("userId is required")
            }

        print(f"Searching for user in Cognito with sub: {user_id}")
        response = cognito_idp.list_users(
            UserPoolId=USER_POOL_ID,
            Filter=f"sub = \"{user_id}\""  # Search for the user by their sub field
        )

        users = response.get('Users', [])
        if not users:
            return {
                "statusCode": 404,
                "body": json.dumps("User not found in Cognito")
            }

        # Extract the Username for the found user
        username = users[0]['Username']
        print(f"Found user in Cognito with Username: {username}")

        # Delete the user from Cognito
        try:
            cognito_idp.admin_delete_user(
                UserPoolId=USER_POOL_ID,
                Username=username  # Use the actual Cognito username
            )
            print(f"User with sub {user_id} deleted from Cognito")
        except Exception as e:
            print(f"Error deleting user from Cognito: {e}")
            return {
                "statusCode": 500,
                "body": json.dumps({"error": str(e)})
            }

        # Delete the user from DynamoDB
        print(f"Attempting to delete user with userId: {user_id}")
        table.delete_item(Key={'User_ID': user_id})
        print(f"User with userId {user_id} deleted successfully")

        return {
            "statusCode": 200,
            "headers": {
                "Content-Type": "application/json",  # Ensures the response is interpreted as JSON
                "Access-Control-Allow-Origin": "*",  # For CORS
            },
            "body": json.dumps("User deleted successfully")
        }

    except Exception as e:
        print(f"Error deleting user: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps({"error": str(e)})
        }
