import json
import boto3
from decimal import Decimal

def decimal_default(obj):
    if isinstance(obj, Decimal):
        return float(obj)
    raise TypeError("Type not serializable")

def lambda_handler(event, context):
    dynamo_client = boto3.resource('dynamodb')
    table = dynamo_client.Table('User_Data')

    try:
        user_id = event['userId']
        month = event['month']
    except KeyError as e:
        return {
            'statusCode': 400,
            'body': json.dumps(f"Missing required key: {str(e)}")
        }

    try:
        response = table.get_item(Key={'User_ID': user_id})
        if 'Item' not in response:
            return {
                'statusCode': 404,
                'body': json.dumps("User not found")
            }

        user_data = response['Item']
        budget_info = user_data.get('BudgetInfo', {}).get(month, {
            'TotalBudget': 0,
            'TotalExpenses': 0,
            'BudgetLeft': 0,
            'Expenses': []
        })

        response_body = {
            'month': month,
            'budget_details': {
                'TotalBudget': budget_info.get('TotalBudget', 0),
                'TotalExpenses': budget_info.get('TotalExpenses', 0),
                'BudgetLeft': budget_info.get('BudgetLeft', 0)
            },
            'expenses_details': budget_info.get('Expenses', [])
        }

        return {
            'statusCode': 200,
            'body': json.dumps(response_body, default=decimal_default)
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f"Error retrieving budget information: {str(e)}")
        }
