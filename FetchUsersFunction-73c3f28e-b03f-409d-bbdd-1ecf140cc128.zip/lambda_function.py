import json
import boto3
from decimal import Decimal

# Initialize DynamoDB and Cognito
dynamodb = boto3.resource('dynamodb')
cognito = boto3.client('cognito-idp')

table_name = "User_Data"
user_pool_id = "us-east-1_jVVBL0a8C"  # Replace with your Cognito User Pool ID
table = dynamodb.Table(table_name)


# Custom JSON encoder to handle Decimal
class DecimalEncoder(json.JSONEncoder):
    def default(self, o):
        if isinstance(o, Decimal):
            return float(o)  # Convert Decimal to float for JSON serialization
        return super(DecimalEncoder, self).default(o)


def lambda_handler(event, context):
    try:
        # Scan all users in DynamoDB
        response = table.scan()
        users = response.get('Items', [])

        # Add `IsAdmin` to each user based on Cognito groups
        for user in users:
            email = user.get('Email')
            if email:
                # Fetch Cognito user to check their groups
                cognito_response = cognito.list_users(
                    UserPoolId=user_pool_id,
                    Filter=f'email="{email}"'
                )
                cognito_users = cognito_response.get('Users', [])
                if cognito_users:
                    cognito_user = cognito_users[0]
                    groups_response = cognito.admin_list_groups_for_user(
                        UserPoolId=user_pool_id,
                        Username=cognito_user['Username']
                    )
                    groups = groups_response.get('Groups', [])
                    user['IsAdmin'] = any(group['GroupName'] == 'Admin' for group in groups)
                else:
                    user['IsAdmin'] = False
            else:
                user['IsAdmin'] = False

        # Return the users as a JSON response
        return {
            "statusCode": 200,
            "headers": {
                "Access-Control-Allow-Origin": "*",
                "Access-Control-Allow-Credentials": "true"
            },
            "body": json.dumps(users, cls=DecimalEncoder)  # Use custom encoder
        }
    except Exception as e:
        print(f"Error fetching user data: {e}")
        return {
            "statusCode": 500,
            "body": json.dumps("Internal server error")
        }
