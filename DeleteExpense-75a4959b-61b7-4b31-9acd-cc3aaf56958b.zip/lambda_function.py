import json
import boto3
from decimal import Decimal

class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)
        return super(DecimalEncoder, self).default(obj)

def lambda_handler(event, context):
    try:
        # Extracting data from the event queryStringParameters
        user_id = event['userId']
        expense_id = event['expenseId']
        month = event['month']

    except KeyError as e:
        return {
            'statusCode': 400,
            'body': json.dumps(f"Missing key: {str(e)}")
        }

    dynamo_client = boto3.resource('dynamodb')
    table = dynamo_client.Table('User_Data')

    try:
        # Retrieving user data
        response = table.get_item(Key={'User_ID': user_id})
        if 'Item' not in response:
            return {
                'statusCode': 404,
                'body': json.dumps(f'User {user_id} not found')
            }

        # Managing and deleting the expense
        budget_info = response['Item'].get('BudgetInfo', {})
        month_info = budget_info.get(month, {})
        expenses_list = month_info.get('Expenses', [])

        # Finding the expense to delete
        expense_to_delete = next((expense for expense in expenses_list if expense['id'] == expense_id), None)
        if not expense_to_delete:
            return {
                'statusCode': 404,
                'body': json.dumps('Expense not found')
            }

        # Remove the expense from the list
        updated_expenses = [expense for expense in expenses_list if expense['id'] != expense_id]

        # Update the remaining budget
        deleted_expense_amount = Decimal(expense_to_delete['Amount'])
        updated_budget_left = Decimal(month_info.get('BudgetLeft', 0)) + deleted_expense_amount
        updated_total_expenses = Decimal(month_info.get('TotalExpenses', 0)) - deleted_expense_amount

        # Update DynamoDB with new values
        month_info['Expenses'] = updated_expenses
        month_info['BudgetLeft'] = updated_budget_left
        month_info['TotalExpenses'] = max(updated_total_expenses, Decimal(0))
        budget_info[month] = month_info

        table.update_item(
            Key={'User_ID': user_id},
            UpdateExpression="SET BudgetInfo = :new_info",
            ExpressionAttributeValues={':new_info': budget_info},
            ReturnValues="UPDATED_NEW"
        )

        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Expense deleted successfully',
                'updatedBudgetLeft': float(updated_budget_left)
            }, cls=DecimalEncoder)
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error deleting expense: {str(e)}')
        }
