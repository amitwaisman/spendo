import json
import boto3
from decimal import Decimal

# פונקציה לעיבוד Decimal
class DecimalEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, Decimal):
            return float(obj)  # המרה ל-float
        return super(DecimalEncoder, self).default(obj)

def lambda_handler(event, context):
    try:
        # בדיקה אם body כבר dict, אם לא, המרה למבנה JSON
        if isinstance(event['body'], str):
            body = json.loads(event['body'])
        else:
            body = event['body']

        user_id = body['userId']
        month = body['month']  # לדוגמה: "2023-01"
        new_budget = Decimal(body['totalBudget'])  # התקציב החדש
    except KeyError as e:
        return {
            'statusCode': 400,
            'body': json.dumps(f'Missing key: {str(e)}')
        }
    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error parsing body: {str(e)}')
        }

    dynamo_client = boto3.resource('dynamodb')
    table = dynamo_client.Table('User_Data')

    try:
        # שליפת נתוני המשתמש
        response = table.get_item(Key={'User_ID': user_id})
        item = response.get('Item', {})

        # אם החודש לא קיים, צור אותו
        if month not in item.get('BudgetInfo', {}):
            table.update_item(
                Key={'User_ID': user_id},
                UpdateExpression="SET BudgetInfo.#month = :default_month",
                ExpressionAttributeNames={'#month': month},
                ExpressionAttributeValues={
                    ':default_month': {
                        'TotalBudget': Decimal(0),
                        'TotalExpenses': Decimal(0),
                        'BudgetLeft': Decimal(0),
                        'Expenses': []
                    }
                }
            )

        # חישוב התקציב שנותר (BudgetLeft)
        current_expenses = item.get('BudgetInfo', {}).get(month, {}).get('TotalExpenses', Decimal(0))
        budget_left = item.get('BudgetInfo', {}).get(month, {}).get('TotalBudget', Decimal(0)) + new_budget
        budget_left -= current_expenses

        # עדכון השדות הספציפיים בתוך החודש
        update_response = table.update_item(
            Key={'User_ID': user_id},
            UpdateExpression="""
                SET BudgetInfo.#month.TotalBudget = if_not_exists(BudgetInfo.#month.TotalBudget, :zero) + :updated_budget,
                    BudgetInfo.#month.BudgetLeft = :budget_left
            """,
            ExpressionAttributeNames={'#month': month},
            ExpressionAttributeValues={
                ':updated_budget': new_budget,
                ':budget_left': budget_left,
                ':zero': Decimal(0)
            },
            ReturnValues="UPDATED_NEW"
        )

        return {
            'statusCode': 200,
            'body': json.dumps({
                'message': 'Budget updated successfully',
                'updatedAttributes': update_response.get('Attributes', {})
            }, cls=DecimalEncoder)
        }

    except Exception as e:
        return {
            'statusCode': 500,
            'body': json.dumps(f'Error updating budget: {str(e)}')
        }
